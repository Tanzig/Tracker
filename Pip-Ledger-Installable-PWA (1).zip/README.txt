PIP LEDGER — INSTALLABLE WEB APP PACKAGE

This package prepares Pip Ledger as a Progressive Web App (PWA). It is not an Android APK.

NEXT STEPS
1. Upload the CONTENTS of this folder to a static web host that provides HTTPS (for example, Netlify Drop).
2. Open the resulting HTTPS website in Chrome on your Samsung phone.
3. In Chrome, tap ⋮ and choose “Install app” or “Add to Home screen”.
4. Launch Pip Ledger from the new home-screen icon.

IMPORTANT
- A local HTML file opened from Downloads cannot register a service worker or be installed as a full PWA. Hosting over HTTPS is required.
- Keep your original HTML file as a backup. Test saving a trade before relying on the app.
- This package does not upload or publish your data; the hosting service will host the app files. Review its privacy terms before uploading.
